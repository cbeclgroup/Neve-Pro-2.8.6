<?php
/**
 * Template used for component rendering wrapper.
 *
 * Name:    Header Footer Grid
 *
 * @package HFG
 */
?>

<div class="component-wrap">
	<div class="divider"></div>
</div>
